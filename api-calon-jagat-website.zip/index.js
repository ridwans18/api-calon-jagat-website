import { PORT } from "./src/config/env.js";
import express from "express";
import produkrouter from "./src/routes/produk.routes.js";
import ordersrouter from "./src/routes/orders.routes.js";
import user_adminrouter from "./src/routes/user_admin.routes.js";
import paymentrouter from "./src/routes/payment.routes.js";
import cors from "cors";
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

app.use("/produk", produkrouter);
app.use("/orders", ordersrouter);
app.use("/user_admin", user_adminrouter);
app.use("/payment", paymentrouter);
app.use(
  cors({
    origin: "http://localhost:5173", // asal frontend kamu
  })
);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
